ES     =("https://us02web.zoom.us/j/89062916407?pwd=ajV4dnFYZkYwb3VtNGVvTWd6SDUwZz09")
OT     =("https://us02web.zoom.us/j/81028565718?pwd=SVc0bFJXTGlqa3VXRGRNWEtoOGpxQT09")
PC     =("https://zoom.us/j/94977149304?pwd=RW9zL3hjbHZ3RHNoMStkWVJ3MmFBQT09")
SPM    =("https://zoom.us/j/3442659865?pwd=VlJZWXRtM3pyNGVxMmorSWkrbXpOUT09")
DS     =("https://zoom.us/j/6964274190?pwd=dGdPV2lXWW1ESmZRSlM0blRPalp3UT09")
DS_Lab =("https://zoom.us/j/6964274190?pwd=dGdPV2lXWW1ESmZRSlM0blRPalp3UT09")
EM_Lab  =("https://us02web.zoom.us/j/89062916407?pwd=ajV4dnFYZkYwb3VtNGVvTWd6SDUwZz09")
VSR_Lab =("https://us02web.zoom.us/j/7062877231?pwd=VE5scXB2WU9leEx4VXRRMnJMbWt0QT09")
TestUrl =("https://us04web.zoom.us/j/4235059415?pwd=RldmQXJ1Q3V2ditPSGlkL2RtZEgzQT09")


# Timings

A=("09:20:00")
B=("10:15:00")
C=("11:10:00")
D=("12:05:00")
E=("13:25:00")
F=("14:20:00")
G=("15:15:00")
