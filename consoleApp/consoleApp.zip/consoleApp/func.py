import urlTime
import time
import webbrowser



def Run():
    print("Running")
    time.sleep(1)
    print(".")
    time.sleep(1)
    print(".")
    time.sleep(1)
    print(".")
    time.sleep(1)
    print(".")
def Test():
            webbrowser.open(urlTime.TestUrl)
            time.sleep(5)
            webbrowser.open(urlTime.TestUrl)
            time.sleep(5)
            webbrowser.open(urlTime.TestUrl)
            time.sleep(5)
            webbrowser.open(urlTime.TestUrl)
            time.sleep(5)
            webbrowser.open(urlTime.TestUrl)
            time.sleep(5)
            webbrowser.open(urlTime.TestUrl)
        


        
        
    
def Monday():
    webbrowser.open(urlTime.ES)
    time.sleep(3300)
    webbrowser.open(urlTime.OT)
    time.sleep(6600)
    webbrowser.open(urlTime.PC)
    time.sleep(6600)
    webbrowser.open(urlTime.VSR_Lab)
    time.sleep(3300)
    webbrowser.open(urlTime.VSR_Lab)
    time.sleep(3300)
    webbrowser.open(urlTime.SPM)
       
def Tuesday():
    webbrowser.open(urlTime.SPM)
    time.sleep(3300)
    webbrowser.open(urlTime.ES)
    time.sleep(3300)
    webbrowser.open(urlTime.PC)
    time.sleep(3300)
    webbrowser.open(urlTime.OT)
    time.sleep(6600)
    webbrowser.open(urlTime.VSR_Lab)
    time.sleep(3300)
    webbrowser.open(urlTime.VSR_Lab)
    time.sleep(3300)
    webbrowser.open(urlTime.VSR_Lab)
    
def Wednesday():
    webbrowser.open(urlTime.PC)
    time.sleep(3300)
    webbrowser.open(urlTime.DS)
    time.sleep(3300)
    webbrowser.open(urlTime.ES)
    time.sleep(3300)
    webbrowser.open(urlTime.OT)
    time.sleep(6600)
    webbrowser.open(urlTime.EM_Lab)
    time.sleep(3300)
    webbrowser.open(urlTime.EM_Lab)
    
def Thursday():
    webbrowser.open(urlTime.PC)
    time.sleep(3300)
    webbrowser.open(urlTime.DS)
    time.sleep(3300)
    webbrowser.open(urlTime.DS_Lab)
    time.sleep(3300)
    webbrowser.open(urlTime.DS_Lab)
    time.sleep(6600)
    webbrowser.open(urlTime.EM_Lab)
    time.sleep(3300)
    webbrowser.open(urlTime.EM_Lab)
    
def Friday():
    webbrowser.open(urlTime.SPM)
    time.sleep(9900)
    webbrowser.open(urlTime.PC)
    time.sleep(6600)
    webbrowser.open(urlTime.PC)
   
